#!/bin/bash
javac *.java
java UnionFindMain $1

